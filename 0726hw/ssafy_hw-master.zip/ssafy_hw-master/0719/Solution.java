import java.util.Scanner;
public class Solution{
	
	public static void main(String[] args) {
		int[][] intArray = { { 1, 2, 3, 4, 5 }, { 6, 7, 8, 9, 10 }, { 11, 12, 13, 14, 15 },
				{ 16, 17, 18, 19, 20 }, };
		int len = intArray.length;
		int size = intArray[0].length;
//대각선 출력
		for (int x = 0; x < len + size-1; x++) {
			for (int i = 0; i < size; i++) {
				for (int j = 0; j < len; j++) {
					if (i + j == x)
						System.out.print(intArray[j][i]+" ");
				}
			}
		}
		System.out.println();
		//지그재그
		for (int x = 0; x < len + size - 1; x++) {
			if (x % 2 == 0) {

				for (int i = 0; i < size; i++) {
					for (int j = 0; j < len; j++) {
						if (i + j == x)
							System.out.print(intArray[j][i]+" ");
					}
				}
			} else {
				for (int i = 0; i < len; i++) {
					for (int j = 0; j < size; j++) {
						if (i + j == x)
							System.out.print(intArray[i][j]+" ");
					}
				}
			}
		}
	}
}