package com.ssafy.hw.step2;
import java.io.*;
import java.util.*;

public class solution {
	static int []dx= {1,-1,0,0};
	static int []dy= {0,0,1,-1};
	static int[][] arr;
	static int n,ans=0,cnt;
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		arr=new int[n][n];
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				arr[i][j]=sc.nextInt();
			}
		}
		
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				cnt=0;
				if(arr[i][j]==1)dir(i,j);
			}
		}
		System.out.println(ans);
				
	}
	
	static void dir(int y,int x) {
		for(int i=0;i<4;i++) {
			int ny=y,nx=x;
			cnt=1;
			while(true) {
				ny=ny+dy[i];
				nx=nx+dx[i];
				if(ny>=n||ny<0||nx>=n||nx<0)break;
				if(arr[ny][nx]==1)break;
				cnt++;
			}
			ans=Math.max(ans, cnt);
		}
	}
}
