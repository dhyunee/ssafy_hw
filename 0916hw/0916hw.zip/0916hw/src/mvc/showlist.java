package mvc;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dto.animal;

@WebServlet("/showlist")
public class showlist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		list(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		list(request,response);
	}

	protected void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		ArrayList<animal>list=new ArrayList<>();
		list.add(new animal("cat","mammalia",15,38,5));
		list.add(new animal("horse","mammalia",25,38,300));
		list.add(new animal("snake","reptile",15,25,5));
		list.add(new animal("shark","fish",25,24,250));
		
		request.setAttribute("list", list);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/list.jsp");
		dispatcher.forward(request, response);
		
	}
}
