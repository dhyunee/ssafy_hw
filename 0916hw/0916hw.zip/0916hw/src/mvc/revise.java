package mvc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/revise")
public class revise extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("process()");
		String action=request.getParameter("action");
		System.out.println("action "+action);
		switch(action) {
		case"revise":
			revise(request,response);
			break;
		default: System.out.println("미지원 서비스입니다");
		break;
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	protected void revise(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//요청 객체에 대한 한글 인코딩 설정
		request.setCharacterEncoding("utf-8");
		//요청데이터 추출: regist.jsp<input type="text" name="id"....>
		String id="ssafy";
		String title=request.getParameter("title");
		String content=request.getParameter("content");

		//응답을 위해 mime-type 설정 browser에 타입 알려줌
		response.setContentType("text/html;charset=utf-8");
		//응답을 위한 출력 스트림 생성 writer
		PrintWriter out=response.getWriter();
		
		//응답 출력스트림을 이용해 동적 페이지 응답
		out.println("<html><head><title>응답</title></head><body>");
		out.println("<h1>글 수정</h1>");
		out.println("<div>아이디:"+id+"</div>");
		out.println("<div>제목:"+title+"</div>");
		out.println("<div>내용:"+content+"</div>");
		out.println("</body></html>");
		
		//출력스트림 자원 해제
		out.close();
	}
}
