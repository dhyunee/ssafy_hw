package Dto;

import java.io.Serializable;

/*DTO(data transfer Object Pattern
* 1.Encapsulatioin
* 2.직렬화 객체
* 3. Java Bean Component 
*/
public class boardwrite implements Serializable{
	private String id;
	private String title;
	private String text;

	
	public boardwrite() {
		
	}


	public boardwrite(String id, String title, String text) {
		super();
		this.id = id;
		this.title = title;
		this.text = text;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}

	
	
}
