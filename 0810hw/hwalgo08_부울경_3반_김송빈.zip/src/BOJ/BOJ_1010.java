package BOJ;
	
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_1010 {

	static long [][]dp;
	static int n,m;
	public static void main(String[] args)throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int t=Integer.parseInt(br.readLine());
		
		for(int i=0;i<t;i++) {
			StringTokenizer st=new StringTokenizer(br.readLine());
			n=Integer.parseInt(st.nextToken());
			m=Integer.parseInt(st.nextToken());
			dp=new long [m+1][n+1];
			dp_cal();
			System.out.println(dp[m][n]);
		}
		

	}

	static void dp_cal(){
		
		for(int k=1;k<=m;k++) {
			dp[k][1]=k;
			for(int i=2;i<n+1;i++) {
				dp[k][i]=dp[k-1][i-1]+dp[k-1][i];
			}
		}
		
	}
}
