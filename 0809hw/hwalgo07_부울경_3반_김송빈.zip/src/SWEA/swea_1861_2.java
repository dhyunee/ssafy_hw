package SWEA;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class swea_1861_2 {

	static int[] dx = {-1, 1, 0, 0};
	static int[] dy = {0, 0, 1, -1};
	static int cnt;
	static int [][]room;
	static int n;
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		StringBuilder sb = new StringBuilder();
		int t = Integer.parseInt(br.readLine());
		
		for(int tc=1;tc<=t;tc++) {
			n = Integer.parseInt(br.readLine());
			room = new int[n][n];
			
			for(int i=0;i<n;i++) {
				st = new StringTokenizer(br.readLine());
				for(int j=0;j<n;j++) {
					room[i][j] = Integer.parseInt(st.nextToken());
				}
			}
		
			int max = 0;
			int start_room = n*n; 
			for(int i=0;i<n;i++) {
				for(int j=0;j<n;j++) {
					cnt = 1;
					dfs( i, j, room[i][j]);
					
					if (cnt>max) {
						start_room = room[i][j];
						max = cnt;
					}
					else if(cnt==max){
						if(start_room>room[i][j]) {
							start_room = room[i][j];
						}
						
						
					}
				}
			}
			sb.append("#"+tc).append(" ").append(start_room+" ").append(max).append("\n");
		}
		System.out.println(sb);
	}
	public static void dfs(int x, int y, int num) {
		for(int i=0;i<4;i++) {
			int nx = x+dx[i];
			int ny = y+dy[i];
			if((0<=nx&&nx<n)&&(0<=ny&&ny<n)&&(room[nx][ny]==num+1)) {
				cnt++;
				dfs( nx, ny, num+1);
			}
		}
	}

}
