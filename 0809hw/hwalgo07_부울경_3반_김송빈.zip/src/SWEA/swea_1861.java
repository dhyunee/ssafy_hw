package SWEA;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.StringTokenizer;

public class swea_1861 {

	static int n;
	static int [][]map;
	static boolean [][] visited;
	static int max;
	static int []dy= {0,0,-1,1},dx= {1,-1,0,0};
	static int cnt;
	static int max_room;
	
	public static void main(String[] args)throws Exception {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int T=Integer.parseInt(br.readLine());
		for(int t=1;t<=T;t++) {
			n=Integer.parseInt(br.readLine());
			
			map=new int [n][n];
			max=0;
			max_room=Integer.MAX_VALUE;
			for(int i=0;i<n;i++) {
				StringTokenizer st=new StringTokenizer(br.readLine());
				for(int j=0;j<n;j++) {
					map[i][j]=Integer.parseInt(st.nextToken());
				}
			}
			for(int i=0;i<n;i++) {
				for(int j=0;j<n;j++) {
					visited=new boolean[n][n];
					bfs(i,j);
					if(max<cnt) {
						max=cnt;
						max_room=map[i][j];
					}
					else if(max==cnt) {
						max_room=Math.min(map[i][j], max_room);
					}
				}
				
				
			}
			System.out.println("#"+t+" "+max_room+" "+max);
		}
	
	}
	static void bfs(int y,int x) {
		Deque<node>q=new ArrayDeque<>();
		cnt=1;
	
		q.offer(new node(y,x));
		while(!q.isEmpty()) {
			node nd=q.poll();
			x=nd.x;
			y=nd.y;
			
			for(int i=0;i<4;i++) {
				int nx=x+dx[i];
				int ny=y+dy[i];
				if(ny>=n||ny<0||nx>=n||nx<0||visited[ny][nx])continue;
				if(map[ny][nx]-map[y][x]==1) {
					y=ny;
					x=nx;
					visited[ny][nx]=true;
					q.offer(new node(y,x));
					cnt++;
				}
			}
		}
		
	}

	static class node{
		int y,x;
		node(int y,int x) {
			this.y=y;
			this.x=x;
		}
	}
}
