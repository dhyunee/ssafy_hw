package hwalgo19_부울경_3반_김송빈;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class boj_10971 {

	static int n,min=Integer.MAX_VALUE;
	static int[][] map;
	static int[] tgt;
	static boolean[] visited;
	
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		map = new int[n][n];
		tgt = new int[n];
		visited=new boolean[n];
		
		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			for (int j = 0; j < n; j++) {
				int x = Integer.parseInt(st.nextToken());
				map[i][j] = x;
			}
		}
		perm(0);
		System.out.println(min);
	}

	static void perm(int tgt_idx) {
		if (tgt_idx == n) {
			int sum=0;
			boolean flag=false;
			for(int i=0;i<n-1;i++) {
				if(map[tgt[i]][tgt[i+1]]==0) {
					flag=true;
					break;
				}
				sum+=map[tgt[i]][tgt[i+1]];
			}
			if(!flag) {
				if(map[tgt[n-1]][0]==0)flag=true;
				else sum+=map[tgt[n-1]][0];
			}
			if(!flag)sum+=map[tgt[n-1]][tgt[0]];
			
			min=Math.min(min, sum);
			return;
		}
		
		for(int i=0;i<n;i++) {
		
			if(!visited[i]) {
				visited[i]=true;
				tgt[tgt_idx]=i;
				perm(tgt_idx+1);
				visited[i]=false;
			}
		}
	}
}

