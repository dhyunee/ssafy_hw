package SWEA;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.StringTokenizer;

public class swea_1238 {
	static int n, a;
	static List<List<Integer>> list;
	static int[] visited;

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		for (int t = 1; t <= 10; t++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			a = Integer.parseInt(st.nextToken());

			visited = new int[101];

			list = new ArrayList<>();
			for (int i = 0; i < 101; i++) {
				list.add(new ArrayList<>());
			}

			st = new StringTokenizer(br.readLine());
			for(int i=0;i<n/2;i++) {
				int y = Integer.parseInt(st.nextToken());
				int x = Integer.parseInt(st.nextToken());

				list.get(y).add(x);
			}

			System.out.print("#"+t+" ");
			bfs();
		}
	}

	static void bfs() {
		Queue<Integer> q = new ArrayDeque<Integer>();
		q.add(a);
		visited[a] = 1;
		int max = 0, max_idx = 0, cnt = 0;
		while (!q.isEmpty()) {
			int x = q.poll();
			for (int i = 0; i < list.get(x).size(); i++) {
				if (visited[list.get(x).get(i)] == 0) {
					q.add(list.get(x).get(i));
					visited[list.get(x).get(i)] = visited[x] + 1;
					cnt++;
				}
			}
		}
		for (int i = 1; i < 101; i++) {
			if (max < visited[i]) {
				max = visited[i];
				max_idx = i;
			} else if (max == visited[i]) {
				max_idx = Math.max(max_idx, i);
			}
		}

		System.out.println(max_idx);
	}

}
