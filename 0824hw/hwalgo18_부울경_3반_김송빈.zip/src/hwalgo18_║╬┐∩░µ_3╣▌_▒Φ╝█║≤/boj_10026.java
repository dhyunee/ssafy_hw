package hwalgo18_�ο��_3��_��ۺ�;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Queue;

public class boj_10026 {
	static int n, rgp = 0, p = 0;
	static boolean[][] visited;
	static char[][] map;
	static int[] dx = { 0, 1, 0, -1 }, dy = { 1, 0, -1, 0 };

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		map = new char[n][n];
		visited = new boolean[n][n];

		int rgcnt = 0, cnt = 0;
		for (int i = 0; i < n; i++) {
			map[i] = br.readLine().toCharArray();
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (!visited[i][j]) {
					bfs(i, j);
					cnt++;
				}
			}
		}
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (map[i][j] == 'R')
					map[i][j] = 'G';
			}
		}

		visited = new boolean[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (!visited[i][j]) {
					bfs(i, j);
					rgcnt++;
				}
			}
		}
		System.out.println(cnt+" "+rgcnt);
	}

	static void bfs(int y, int x) {
		Queue<int[]> q = new ArrayDeque<int[]>();
		q.offer(new int[] { y, x });
		visited[y][x] = true;
		while (!q.isEmpty()) {
			int[] a = q.poll();
			int xx = a[1];
			int yy = a[0];

			for (int i = 0; i < 4; i++) {
				int nx = xx + dx[i];
				int ny = yy + dy[i];
				if (nx < 0 || ny < 0 || nx >= n || ny >= n)
					continue;
				if (!visited[ny][nx] && map[ny][nx] == map[y][x]) {
					visited[ny][nx] = true;
					q.offer(new int[] {ny,nx});
				}
			}
		}

	}
}
