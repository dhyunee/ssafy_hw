package board.dao;

import board.dto.BoardDto;

public interface BoardDao {
	int boardwrite(BoardDto boardDto);
}
