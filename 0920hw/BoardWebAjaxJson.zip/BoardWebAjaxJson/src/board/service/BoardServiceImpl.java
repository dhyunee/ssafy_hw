package board.service;

public class BoardServiceImpl {

}
