package SWEA;

public class swea_1225 {

}
