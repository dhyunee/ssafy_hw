package SWEA;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class swea_9229_1 {

	public static void main(String[] args)throws Exception {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb=new StringBuilder();
		
		int tc=Integer.parseInt(br.readLine());
	
		for(int t=1;t<=tc;t++) {
			StringTokenizer st=new StringTokenizer(br.readLine());
			int n=Integer.parseInt(st.nextToken());
			int m=Integer.parseInt(st.nextToken());
			
			int arr[]=new int[n];
			st=new StringTokenizer(br.readLine());
			for(int i=0;i<n;i++) {
				arr[i]=Integer.parseInt(st.nextToken());
			}
			
			
			int max=-1;
			for(int i=0;i<n;i++) {
				for(int j=i+1;j<n;j++) {
					int cal=arr[i]+arr[j];
					if(cal<=m)max=Math.max(cal,max);
				}
			}
			sb.append("#"+t+" ").append(max).append("\n");
		}
		System.out.println(sb.toString());
	}

}
