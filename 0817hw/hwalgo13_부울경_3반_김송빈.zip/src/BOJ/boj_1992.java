package BOJ;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class boj_1992 {

	static int n;
	static int[][] map;
	static StringBuilder sb = new StringBuilder();

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		n = Integer.parseInt(br.readLine());
		map = new int[n][n];

		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			String str = st.nextToken();
			for (int j = 0; j < n; j++) {
				map[i][j] = str.charAt(j) - '0';
			}
		}
		solve(n, 0, 0);
		System.out.println(sb);
	}

	static void solve(int size, int y, int x) {

		int cnt_1 = 0, cnt_0 = 0;
		for (int i = y; i < y+size; i++) {
			for (int j = x; j < x+size; j++) {
				if (map[i][j] == 1)
					cnt_1++;
				else
					cnt_0++;
			}
		}
		if (cnt_0 == size * size) {
			sb.append(0);
			return;
		}
		if (cnt_1 == size * size) {
			sb.append(1);
			return;
		}
		sb.append("(");
		solve(size / 2, y, x);
		solve(size / 2, y, x + size / 2);
		solve(size / 2, y + size / 2, x);
		solve(size / 2, y + size / 2, x + size / 2);
		sb.append(")");
	}

}