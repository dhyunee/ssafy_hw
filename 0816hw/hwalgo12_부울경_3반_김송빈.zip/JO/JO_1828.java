package JO;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class JO_1828 {

	public static void main(String[] args) throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		int [][]c=new int [n+1][2];
		
		for(int i=1;i<n+1;i++) {
			StringTokenizer st=new StringTokenizer(br.readLine());
			c[i][0]=Integer.parseInt(st.nextToken());
			c[i][1]=Integer.parseInt(st.nextToken());
		}

		Arrays.sort(c,(i1,i2)->i1[1]==i2[1]?i1[0]-i2[0]:i1[1]-i2[1]);
		
		int prev_h=c[1][1];
		int cnt=1;
		for(int i=2;i<n+1;i++) {
			if(prev_h<c[i][0]) {
				cnt++;
				prev_h=c[i][1];
			}
		}
		System.out.println(cnt);
	}

}
